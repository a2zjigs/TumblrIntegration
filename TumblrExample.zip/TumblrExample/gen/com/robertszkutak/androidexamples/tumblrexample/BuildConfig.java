/** Automatically generated file. DO NOT MODIFY */
package com.robertszkutak.androidexamples.tumblrexample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}